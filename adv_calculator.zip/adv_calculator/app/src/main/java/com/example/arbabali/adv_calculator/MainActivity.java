package com.example.arbabali.adv_calculator;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    DateBaseHelper myDb;
    Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b0,badd,bsub,bmul,bdiv,bdot,bequal,bclear,bbck,bresult,bRec,bDisplay;
    EditText ans,eq;
    double var1,var2;
    String str = null;
    double []values = new double[20];
    String operators="";
    int valuesCount = 0,opCounter=0,limiter=0;
    private boolean isOperator(char st)
    {
        if(st == '+' || st == '-' || st == '/' || st == '*')
        {
            return true;
        }
        return false;
    }
    private boolean isValidEquation(String st)
    {
        for(int count=0;count<st.length();count++)
        {
            if(isOperator(st.charAt(0)) == true )
            {
                return false;
            }
            else if(isOperator(st.charAt(count)) == true && isOperator(st.charAt(count + 1)) == true && count<st.length() - 1)
            {
                return false;
            }
            else if(isOperator(st.charAt(st.length() - 1)) == true)
            {
                return false;
            }
        }
        return true;
    }
    private String getOperators(String st)
    {
        String operate = "";
        for(int count=0;count<st.length();count++)
        {
            if(st.charAt(count) == '+' || st.charAt(count) == '-' || st.charAt(count) == '/' || st.charAt(count) == '*')
            {
                operate = operate + st.charAt(count);
            }
        }
        return operate;
    }
    private String backSpace(String st)
    {
        String newSt = "";
        for(int count=0;count<st.length()-1;count++)
        {
            newSt = newSt + st.charAt(count);
        }
        return newSt;
    }
        private void getValues(String st)
        {
            st = st + ',';
            String temp = "";
            for(int count=0;count<st.length();count++)
            {
                if(st.charAt(count) != '+' && st.charAt(count) != '-' && st.charAt(count) != '/' && st.charAt(count) != '*' && st.charAt(count) != ',')
                {
                    temp = temp + st.charAt(count);
                }
                else
                {
                    values[valuesCount] = Double.parseDouble(temp);
                    temp = "";
                    valuesCount++;
                }
            }

        }
    private int getPrecidence(String st)
    {
        for(int count=0;count<st.length();count++)
        {
            if(st.charAt(count) == '/')
            {
                return count;
            }
        }
        for(int count=0;count<st.length();count++)
        {
            if(st.charAt(count) == '*')
            {
                return count;
            }
        }
        for(int count=0;count<st.length();count++)
        {
            if(st.charAt(count) == '-')
            {
                return count;
            }
        }
        for(int count=0;count<st.length();count++)
        {
            if(st.charAt(count) == '+')
            {
                return count;
            }
        }
        return -1111;
    }
    private void reduceValue(int preci)
    {
        double[] value = new double[20];
        for(int count=0,count1=0;count<valuesCount;count++)
        {
            if(count != preci + 1)
            {
                value[count1] = values[count];
                count1++;
            }
        }
        values = null;
        valuesCount--;
        values = new double[20];
        for (int count=0;count<valuesCount;count++)
        {
            values[count] = value[count];
        }
        value = null;
    }

    private void reduceOperators(int preci)
    {
        String newOperate = "";
        for(int count=0;count<operators.length();count++) {
            if (count != preci) {
                newOperate = newOperate + operators.charAt(count);
            }
        }
        operators = "";
        operators = newOperate;
        newOperate = "";
    }
     private double eqSolver(String st)
     {
         valuesCount = 0;
         values = null;
         values = new double[20];
         getValues(st);
         int numOfOp = operators.length(), preci = 0;
         double val1 = 0, val2 = 0;
         for(int count = 0;count<numOfOp;count++)
         {
             preci = getPrecidence(operators);
             val1 = values[preci];
             val2 = values[preci + 1];
             if(operators.charAt(preci) == '/')
             {
                values[preci] = val1 / val2;
             }
             else if(operators.charAt(preci) == '*')
             {
                 values[preci] = val1 * val2;
             }
             else if(operators.charAt(preci) == '+')
             {
                 values[preci] = val1 + val2;
             }
             else if(operators.charAt(preci) == '-')
             {
                 values[preci] = val1 - val2;
             }
             reduceValue(preci);
             reduceOperators(preci);
         }
         return values[0];
     }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bRec = (Button) findViewById(R.id.btnRec);
       myDb = new DateBaseHelper(this);
        bresult = (Button) findViewById(R.id.btnresult);
        bbck = (Button) findViewById(R.id.btnbck);
        b1 = (Button) findViewById(R.id.btn1);
        b2 = (Button) findViewById(R.id.btn2);
        b3 = (Button) findViewById(R.id.btn3);
        b4 = (Button) findViewById(R.id.btn4);
        b5 = (Button) findViewById(R.id.btn5);
        b6 = (Button) findViewById(R.id.btn6);
        b7 = (Button) findViewById(R.id.btn7);
        b8 = (Button) findViewById(R.id.btn8);
        b9 = (Button) findViewById(R.id.btn9);
        b0 = (Button) findViewById(R.id.btn0);
        badd = (Button) findViewById(R.id.btnadd);
        bsub = (Button) findViewById(R.id.btnsub);
        bequal = (Button) findViewById(R.id.btnequal);
        bmul = (Button) findViewById(R.id.btnmul);
        bdiv = (Button) findViewById(R.id.btndiv);
        bdot = (Button) findViewById(R.id.btndot);
        bclear = (Button) findViewById(R.id.btnclear);
        eq =  (EditText) findViewById(R.id.resText);
        ans =  (EditText) findViewById(R.id.eqText);
        bDisplay = (Button) findViewById(R.id.btnDisplay);
        eq.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int inType = eq.getInputType(); // backup the input type
                eq.setInputType(InputType.TYPE_NULL); // disable soft input
                eq.onTouchEvent(event); // call native handler
                eq.setInputType(inType);

                return true;
            }
        });
        ans.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int inType = ans.getInputType(); // backup the input type
                ans.setInputType(InputType.TYPE_NULL); // disable soft input
                ans.onTouchEvent(event); // call native handler
                ans.setInputType(inType);
                return true;
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ans.setText(ans.getText() + "1");
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ans.setText(ans.getText() + "2");
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ans.setText(ans.getText() + "3");
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ans.setText(ans.getText() + "4");
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ans.setText(ans.getText() + "5");
            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ans.setText(ans.getText() + "6");
            }
        });
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ans.setText(ans.getText() + "7");
            }
        });
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ans.setText(ans.getText() + "8");
            }
        });
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ans.setText(ans.getText() + "9");
            }
        });
        b0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ans.setText(ans.getText()+"0");
            }
        });
        bdot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ans.setText(ans.getText()+".");

                }
        });
        bdiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s;
                s = ans.getText().toString();
                if(s.charAt(s.length()-1)!='/' && s.charAt(s.length()-1)!='+' && s.charAt(s.length()-1)!='-' && s.charAt(s.length()-1)!='*' && getOperators(ans.getText().toString()).length()<=19) {
                    ans.setText(ans.getText() + "/");
                }
            }
        });
        bmul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                  String s;
                  s = ans.getText().toString();
                  if(s.charAt(s.length()-1)!='/' && s.charAt(s.length()-1)!='+' && s.charAt(s.length()-1)!='-' && s.charAt(s.length()-1)!='*' && getOperators(ans.getText().toString()).length()<=19) {
                        ans.setText(ans.getText() + "*");
                        limiter++;
                    }
            }
        });
        bsub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s;
                s = ans.getText().toString();
                if (s.charAt(s.length() - 1) != '/' && s.charAt(s.length() - 1) != '+' && s.charAt(s.length() - 1) != '-' && s.charAt(s.length() - 1) != '*' && getOperators(ans.getText().toString()).length()<=19) {
                    ans.setText(ans.getText() + "-");
                    limiter++;
                }
            }
        });
        badd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s;
                s = ans.getText().toString();
                if(s.charAt(s.length()-1)!='/' && s.charAt(s.length()-1)!='+' && s.charAt(s.length()-1)!='-' && s.charAt(s.length()-1)!='*' && limiter<=19) {
                    ans.setText(ans.getText() + "+");
                    limiter++;
                }
            }
        });
        bequal.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                str = ans.getText().toString();
                if (isValidEquation(str) == true && getOperators(ans.getText().toString()).length()<=19)
                {
                    operators = getOperators(str);
                    getValues(str);
                    eq.setText(eqSolver(str) + "");
                    myDb.insertDate(ans.getText().toString(), Double.parseDouble(eq.getText()+""));

                }
                else
                {
                    eq.setText("Syntax Error" + "");
                }
            }
        });
        bclear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ans.setText("");
                eq.setText("");
            }
        });
        bbck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ans.setText(backSpace(ans.getText().toString()));
            }
        });
        bresult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String result = eq.getText().toString() + '.';
                if(result.length() > 1)
                {
                    ans.setText(eq.getText());
                    eq.setText("");
                }
            }
        });
        bRec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(MainActivity.this,second_activity.class);
                startActivity(i);
                }
        }
        );
        bDisplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res = myDb.getAllData();
                //tRec.setText(res.toString());
                if(res.getCount() == 0)
                {
                    showMessage("Error ","No record found!");
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext())
                {
                    buffer.append("ID: " + res.getString(0) + "\n");
                    buffer.append("Equation: " + res.getString(1) + "\n");
                    buffer.append("Result: " + res.getString(2) + "\n\n");
                };
                showMessage("Records",buffer.toString());
            }
        });
    }
    public void showMessage(String title, String Message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
}


