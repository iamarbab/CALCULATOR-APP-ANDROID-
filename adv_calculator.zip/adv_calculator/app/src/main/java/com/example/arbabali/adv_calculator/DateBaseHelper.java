package com.example.arbabali.adv_calculator;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DateBaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "Calculations.db";
    public static final String TABLE_NAME = "Record";
    public static final String col1 = "id";
    public static final String col2 = "Equation";
    public static final String col3 = "Result";
    public DateBaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + "(id integer primary key AUTOINCREMENT, Equation String, result double);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    onCreate(db);
    }
    public boolean insertDate(String equation, double result)
    {
        SQLiteDatabase db =  this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(col2, equation);
        contentValues.put(col3,result);
        long res = db.insert(TABLE_NAME,null,contentValues);
        if(res == -1)
        {
            return  false;
        }
        else
        {
           return true;
        }
    }
    public Cursor getAllData()
    {
        SQLiteDatabase db =  this.getWritableDatabase();
        Cursor res =  db.rawQuery("select * from " + TABLE_NAME,null);
        return res;
    }
}
