package com.example.arbabali.adv_calculator;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class second_activity extends Activity {
    Button btBack;
    TextView tRec;
    DateBaseHelper myDb;
    private void displayRecords()
    {
        Cursor res = myDb.getAllData();
        tRec.setText(res.toString());
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.secon_activity);
        btBack = (Button) findViewById(R.id.btnBack);
        btBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(second_activity.this,MainActivity.class);
                startActivity(i);
            }
        }
        );


    }

}
